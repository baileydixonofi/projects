<?php
include_once 'dbh.inc.php';


$taskid = $_POST['taskid'];

$sql = "UPDATE Tasks SET status='Completed' WHERE id = '$taskid';";
mysqli_query($conn, $sql);

header("LOCATION: ../../index.php");