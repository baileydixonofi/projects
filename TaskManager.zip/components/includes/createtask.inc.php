<?php
include_once 'dbh.inc.php';


$status = "Open";
$summarytext = $_POST['summary'];
$deadline = $_POST['deadline'];

$summary = preg_replace('/[^a-zA-Z0-9_ %\[\]\.\(\)%&-]/s', '', $summarytext);

$sql = "INSERT INTO Tasks (summary, deadline, status) VALUES ('$summary', '$deadline', '$status')";
mysqli_query($conn, $sql);

header("LOCATION: ../../index.php");