<?php
$dbServername1 = "localhost";
$dbUsername1 = "root";
$dbPassword1 = "";
$dbName1 = "taskmanager";

$conn = mysqli_connect($dbServername1, $dbUsername1, $dbPassword1, $dbName1);