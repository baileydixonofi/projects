<?php
include_once 'components/includes/dbh.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>Task Manager</title>
	<link rel="icon" type="png" href="../icons/favicon.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="components/stylesheet.css">
</head>

<body>
	<div id="modalContainer">
        <div id="NewTaskModal" style="display: none;">
        	<p class="Heading1">Create a New Task</p>

        	<form style="margin: 40px auto; width: 400px; max-width: 100%;" method="POST" action="components/includes/createtask.inc.php">
        		<label for='deadline'>Deadline</label><br>
        		<input style="margin-top: 20px; margin-bottom: 40px;" class="Alt" type="date" name="deadline"><br>

        		<label for='summary'>Summary</label><br>
        		<textarea style="margin: 20px 0px 0px 0px; resize: none;" cols='60' rows='7' class="Alt" name="summary"></textarea><br>

        		<button class="PrimaryButton" style="width: 350px; max-width: 100%; position: static; border-radius: 10pt; font-size: 10pt; border: none; margin: 20px auto;">Create Task</button>
        	</form>
        </div>
    </div>


    <div class="Content">
        <div class="Greeting">
            <p class="Heading1 dynamicgreeting"></p>
            <p>Here's your tasks:</p>
        </div>

        <div class="TaskContainer">
        	<?php
        	$sql = "SELECT * FROM Tasks WHERE status != 'Completed';";
      		$result = mysqli_query($conn, $sql);
      		$resultCheck = mysqli_num_rows($result);
      		if ($resultCheck > 0) {
				echo "<hr>";

				while ($row = mysqli_fetch_assoc($result)) {
    				$summary = $row['summary'];
    				$duedate = $row['deadline'];
    				$today = date('Y-m-d');

    				if ($today > $duedate) {
        				$overdue = 'True';
        			} else {
        				$overdue = 'False';
        			}

    				if (strlen($row['summary']) > 30) {
        				$ShortSummary = substr($summary, 0, 27);
        				$Summary = $ShortSummary."...";
    				} else {
        				$Summary = $row['summary'];
    				}

    				echo "
    				<form style='float: left; margin-right: 10px' method='POST' action='components/includes/completetask.inc.php'>
    					<input type='hidden' name='taskid' value='".$row['id']."'>
    					<button type='submit' class='Checkbox'></button>
    				</form>";
        			
        			if ($overdue == 'True') {
        				echo "
        				<p style='float: left; text-align: left; color: #C42424'>".$Summary."</p>
        				<p style='float: right; color: #C42424'>".$duedate."</p>";
        			} else {
        				echo "
        				<p style='float: left; text-align: left'>".$Summary."</p>
        				<p style='float: right'>".$duedate."</p>";
        			}

        			echo "
        			<div class='clearfix'></div>
        			<br><hr>";
				}
			} else {
				echo "<p>There's no tasks right now. Start by creating one. Click the + below.</p>";
			}
        	?>
        </div>

    <a id="NewTaskButton" href="javascript:newTask();" class="PrimaryButton">+</a>

	<script type="text/javascript">
    	var todaysDate = new Date();
    	var hrs = todaysDate.getHours();
    	var greet;

    	if (hrs < 12)
        	greet = 'Good Morning';
    	else if (hrs >= 12 && hrs <= 17)
    	    greet = 'Good Afternoon';
    	else if (hrs >= 17 && hrs <= 24)
    	    greet = 'Good Evening';

    	document.querySelector('.dynamicgreeting').innerHTML =
        '<b>' + greet + ' </b>';

    
    	function newTask() {
        	var newtask = document.getElementById('NewTaskModal');
        	var newTaskButton = document.getElementById('NewTaskButton');

        	if (newtask.style.display === 'none') {
        	    newtask.style.display = 'block';
        	    newTaskButton.innerHTML = 'X';
        	} else {
        	    newtask.style.display = 'none';
        	    newTaskButton.innerHTML = '+';
       		}
    	}
	</script>

</body>
</html>
