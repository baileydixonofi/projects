<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once 'components/includes/dbh.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="components/stylesheet.css">
	<title>Prestige Car Care</title>
</head>
<body>
	<?php
	include_once 'components/secondaryheader.php';
	?>

	<div class='StandardContainer'>
		<div style='display: block; width: 100%; height: 60vh;'>
			<img src="components/images/tick.png" alt="Success" width="100px" style="margin-bottom: 40px">

			<h2 class="Heading2" style="margin-bottom: 30px">Your booking is confirmed</h2>

			<p style="line-height: 30px; margin-bottom: 50px">We've received your valet request. We'll be in touch shortly to confirmed a data and time.<br>In the meantime, feel free to give us a call.</p>

			<a class="PrimaryButton2" href="tel:07000000000">+44 0000 000000</a>
		</div>
	</div>

	<?php
	include_once 'components/mainfooter.php';
	?>
</body>
</html>