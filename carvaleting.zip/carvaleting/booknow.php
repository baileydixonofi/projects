<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once 'components/includes/dbh.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="components/stylesheet.css">
	<title>Prestige Car Care</title>
</head>
<body>
	<?php
	include_once 'components/secondaryheader.php';
	?>

	<?php
	if (!isset($_GET['package'])) {
		echo "
		<div class='StandardContainer' style='text-align: left'>
			<h2 class='Heading2' style='margin-bottom: 65px;'>Choose Your Package</h2>

			<div style='display: block; width: 100%'>
				<div class='Card' style='width: 350px; padding: 25px; display: inline-block; margin: 0px 30px; text-align: center'>
					<h2 class='Heading2' style='margin-bottom: 15px'>Mini Valet</h2>
					<p style='margin-bottom: 45px'>From £20</p>

					<a href='booknow.php?package=Mini' class='PrimaryButton2' style='box-sizing: border-box'>Choose Package</a><br><br>
				</div>

				<div class='Card' style='width: 350px; padding: 25px; display: inline-block; margin: 0px 30px; text-align: center'>
					<h2 class='Heading2' style='margin-bottom: 15px'>Full Valet</h2>
					<p style='margin-bottom: 45px'>From £40</p>

					<a href='booknow.php?package=Full' class='PrimaryButton2' style='box-sizing: border-box'>Choose Package</a><br><br>
				</div>
			</div>
		</div>

		<div class='StandardContainer'>
		<h2 class='Heading2' style='margin-bottom: 20px'>Or Shop the range</h2>

		<div style='width: 100%; overflow-x: scroll; white-space: nowrap; box-sizing: border-box; text-align: left;'>";

			$sql = "SELECT * FROM Products;";
			$result = mysqli_query($conn, $sql);
			$resultCheck = mysqli_num_rows($result);
			if ($resultCheck > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$productid = $row['id'];
					$productimage = $row['image'];
					$productname = $row['name'];
					$description = $row['description'];
					$cost = $row['cost'];
					echo "
					<div class='Card' style='width: 250px; height: 350px; display: inline-block; margin: 30px;'>
						<img src='components/images/".$productimage."' alt='".$productimage."' style='border-radius: 10px; margin-bottom: 15px' width='100%'>
						<h2 class='Heading2' style='font-size: 18px; margin-bottom: 25px'>".$productname."</h2>
						<p style='font-size: 13px; margin-bottom: 15px; height: 40px'>".$description."</p>

						<h2 class='Heading2' style='font-size: 18px; margin-bottom: 25px; color: #DF4242'>£".$cost."</h2>

						<a class='PrimaryButton2' style='box-sizing: border-box'>View Details</a>
					</div>";
					}
			}
			echo "
		</div>
	</div>";
	} else {
		echo "
		<div class='StandardContainer' style='text-align: left'>
		<div style='display: block; width: 100%'>
			<a class='Link1' href='booknow.php'>< Change Package</a><br><br>
			<h2 class='Heading2' style='margin-bottom: 65px;'>Chosen Package: ".$_GET['package']." Valet</h2>
		</div>

		<div style='display: block; width: 100%;'>
			<form method='POST' action='components/includes/booknow.inc.php'>
				<input type='hidden' name='package' value='".$_GET['package']."'>

				<input type='text' name='name' placeholder='Your Name'>
				<input type='text' name='mobile' placeholder='Mobile Number'>

				<button type='submit' class='PrimaryButton2'>Book Now</button>
			</form>
		</div>
		</div>";
	}
	?>

	<?php
	include_once 'components/mainfooter.php';
	?>
</body>
</html>