<?php
include_once 'dbh.inc.php';

$name = $_POST['name'];
$package = $_POST['package'];

function filterMobileNumber($mobile) {
    // Remove all non-numeric characters
    $mobile = preg_replace('/[^0-9]/', '', $mobile);
    
    // Check if the number starts with '+44'
    if (substr($mobile, 0, 3) === '+44') {
        return $mobile; // Return unchanged if already in +44 format
    }
    
    // Check if the number starts with '0' (UK format)
    if (substr($mobile, 0, 1) === '0') {
        // Replace the leading '0' with '+44'
        $mobile = '+44' . substr($mobile, 1);
    }
    
    // Check if the number starts with '+'
    if (substr($mobile, 0, 1) !== '+') {
        // If not, prepend '+44'
        $mobile = '+' . $mobile;
    }
    
    return $mobile;
}



$mobile = $_POST['mobile'];
$formattedmobile = filterMobileNumber($mobile);

$sql = "INSERT INTO Bookings (name, mobile, package) VALUES ('$name', '$formattedmobile', '$package');";
mysqli_query($conn, $sql);

header("LOCATION: ../../bookingconfirmed.php");