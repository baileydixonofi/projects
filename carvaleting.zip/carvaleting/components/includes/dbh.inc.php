<?php
$dbServername1 = "localhost";
$dbUsername1 = "databaseuser";
$dbPassword1 = "";
$dbName1 = "PrestigeCarCare";

$conn = mysqli_connect($dbServername1, $dbUsername1, $dbPassword1, $dbName1);
?>