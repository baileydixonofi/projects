<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Main Footer</title>
</head>
<body>
	<footer class="Footer">
    <div class="SectionContainer">
        <!-- Footer content goes here -->
        <p style="color: #FFFFFF">&copy; 2024 Prestige Car Care</p>
    </footer>
</div>
</body>
</html>