<?php
include_once 'includes/dbh.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Main Header</title>
</head>
<body>
	<div class="Header">
		<div style="float: left; height: 50px; width: 200px; text-align: left;">
			<img src='components/images/logo.png' alt='Logo' height='100%'>
		</div>

		<div style="float: right; height: 50px; width: calc(100% - 210px); box-sizing: border-box;">
			<a class='PrimaryButton1' href="booknow.php" style="margin-top: 7px; float: right">Book Now</a>
		</div>
	</div>

	<div style="height: 63px"></div>
</body>
</html>