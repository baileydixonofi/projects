<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once 'components/includes/dbh.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="components/stylesheet.css">
	<title>Prestige Car Care</title>
</head>
<body>
	<?php
	include_once 'components/mainheader.php';
	?>

	<div class="Hero">
		<div class="HeroContainer">
			<h1 class="Heading1" style="display: block; margin-bottom: 20px">Step in to a world of Prestige.</h1>
		</div>

		<div class="HeroContainer">
			<a class='PrimaryButton1' href="#packages">View Packages</a>
		</div>

		<div class="HeroContainer" style="position: absolute; bottom: 0; margin-bottom: 55px;">
			<img src="components/images/arrowdown.png" alt="Arrow Pointing Down" width="10px" style="display: inline; vertical-align: middle; margin-right: 5px">
			<p style="color: #FFFFFF; display: inline; vertical-align: middle;">Scroll</p>
		</div>
	</div>

	<div id="packages" class="StandardContainer" style="margin: 100px auto;">
		<div style="width: 50%; box-sizing: border-box; padding-right: 15px; float: left">
			<div class="Card" style="width: 100%">
				<img src="components/images/minivalet.png" alt="Mine Valet Image" style="margin: -15px; width: calc(100% + 30px); border-radius: 15px 15px 0px 0px; margin-bottom: 15px">
				<h1 class="Heading2">Mini Valet</h1>

				<p style="font-size: 13px; margin-top: 20px">The Mini Valet package is our budget friendly offering.</p>

				<p style="font-size: 13px; margin-top: 45px">Exterior washed and dried</p>
				<p style="font-size: 13px; margin-top: 20px">Interior vacuumed</p>
				<p style="font-size: 13px; margin-top: 20px">Windows cleaned</p>
				<p style="font-size: 13px; margin-top: 20px; margin-bottom: 45px">Air freshener of your choice</p>

				<a class='PrimaryButton2' href="booknow.php?package=Mini" style="margin-top: 45px">£20.00</a><br><br>
			</div>
		</div>

		<div style="width: 50%; box-sizing: border-box; padding-left: 15px; float: right">
			<div class="Card" style="width: 100%">
				<img src="components/images/fullvalet.png" alt="Mine Valet Image" style="margin: -15px; width: calc(100% + 30px); border-radius: 15px 15px 0px 0px; margin-bottom: 15px;">
				<h1 class="Heading2">Full Valet</h1>

				<p style="font-size: 13px; margin-top: 20px">The Full Valet package offers a prestige experience.</p>

				<p style="font-size: 13px; margin-top: 45px">Exterior washed, dried & wiped with detailing spray</p>
				<p style="font-size: 13px; margin-top: 20px">Windows, trims & tyres cleaned</p>
				<p style="font-size: 13px; margin-top: 20px">Interior cleaned and and left smelling amazing</p>
				<p style="font-size: 13px; margin-top: 20px; margin-bottom: 45px">Interior gets a new car feeling</p>

				<a class='PrimaryButton2' href="booknow.php?package=Full">£40.00</a><br><br>
			</div>
		</div>
	</div>

	<div class="StandardContainer">
		<h2 class="Heading2" style='margin-bottom: 20px'>Shop the range</h2>

		<div style="width: 100%; overflow-x: scroll; white-space: nowrap; box-sizing: border-box; text-align: left;">
			<?php
			$sql = "SELECT * FROM Products;";
			$result = mysqli_query($conn, $sql);
			$resultCheck = mysqli_num_rows($result);
			if ($resultCheck > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$productid = $row['id'];
					$productimage = $row['image'];
					$productname = $row['name'];
					$description = $row['description'];
					$cost = $row['cost'];
					echo "
					<div class='Card' style='width: 250px; height: 350px; display: inline-block; margin: 30px;'>
						<img src='components/images/".$productimage."' alt='".$productimage."' style='border-radius: 10px; margin-bottom: 15px' width='100%'>
						<h2 class='Heading2' style='font-size: 18px; margin-bottom: 25px'>".$productname."</h2>
						<p style='font-size: 13px; margin-bottom: 15px; height: 40px'>".$description."</p>

						<h2 class='Heading2' style='font-size: 18px; margin-bottom: 25px; color: #DF4242'>£".$cost."</h2>

						<a class='PrimaryButton2' style='box-sizing: border-box'>View Details</a>
					</div>";
					}
			}
			?>
		</div>
	</div>

	<div class="StandardContainer">
		<div style="width: 50%; box-sizing: border-box; padding-right: 15px; float: left">
			<iframe class="Card" style="width: 100%; height: 350px; padding: 0px" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d295218.90292117617!2d-2.1273450703971304!3d54.68502921509144!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487c2be1c6b5e0ad%3A0x30cf99eed6cb6c0!2sCounty%20Durham!5e0!3m2!1sen!2suk!4v1711408766001!5m2!1sen!2suk" width="600" height="450" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</div>

		<div style="width: 50%; box-sizing: border-box; padding-left: 15px; float: right">
			<div class="Card" style="width: 100%; height: 350px; text-align: left; padding: 35px">
				<h2 class="Heading2" style="margin-bottom: 25px">Speak to us today</h2>

				<p style="margin-bottom: 40px">Give us a call today to see how we could help.</p>

				<a class='PrimaryButton2' href="tel:07000000000">+44 0000 000000</a><br><br>
			</div>
		</div>
	</div>

	<?php
	include_once 'components/mainfooter.php';
	?>
</body>
</html>